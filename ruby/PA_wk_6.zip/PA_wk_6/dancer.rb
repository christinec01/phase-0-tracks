class Dancer
    attr_accessor :age, :card
    def initialize(name, age)
      @name = name
      @age = 33
      @card = []
    end
    def name
      @name = "Misty Copeland"
    end

    def pirouette
       "*twirls*"
    end

    def bow
      "*bows*"
    end

    def queue_dance_with(next_dancer)
      @card << next_dancer
    end

    def begin_next_dance
      dancer_up = @card.shift
      "Now dancing with #{dancer_up}."
    end

    def get_flowers
        "Gets flowers and gives thanks to crowd"
    end

end

def calculate(user_calculation)

  if !user_calculation.include?"+"||"-"||"*"||"/"
   puts "Not a valid"
 end
  if user_calculation.include? "+"
    new_user_calculation = user_calculation.split('+')
    answer = new_user_calculation[0].to_i + new_user_calculation[1].to_i
    answer
  elsif user_calculation.include? "-"
    new_user_calculation = user_calculation.split('-')
    answer = new_user_calculation[0].to_i - new_user_calculation[1].to_i
    answer
  elsif user_calculation.include? "*"
    new_user_calculation = user_calculation.split('*')
    answer = new_user_calculation[0].to_i * new_user_calculation[1].to_i
    answer
  elsif user_calculation.include? "/"
    new_user_calculation = user_calculation.split('/')
    answer = new_user_calculation[0].to_i / new_user_calculation[1].to_i
    answer
  end
  puts "Thank you. #{user_calculation} is equal to #{answer}"
  answer
end
# puts "=====Driver code======"
# puts  calculate(2, "+", 2) == 4
# puts calculate(1, "*", 30) == 30
# puts calculate(44, "-", 24) == 20
# puts calculate(20, "/", 10) == 2
calculations_hash = {}
calculating = true
while calculating do
  calculating = false
    puts "Please enter a calculation you would like me to compute."
    user_calculation = gets.chomp
    calculations_hash[user_calculation] = calculate(user_calculation)
     puts "Would you like to enter another calculation?"
    user_response = gets.chomp
   if user_response == "yes"
     calculating = true
   end
 end
 puts "Here are the calculations we performed:"
 print calculations_hash
